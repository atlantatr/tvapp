package com.turktvbox.live.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.turktvbox.live.R
import com.turktvbox.live.model.Channel

class ChannelAdapter(
    private val channels: List<Channel>,
    private val onChannelClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    private var focusedPosition = 0

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val channelName: TextView = itemView.findViewById(R.id.tvChannelName)
        val channelLogo: ImageView = itemView.findViewById(R.id.ivChannelLogo)
        val channelCategory: TextView = itemView.findViewById(R.id.tvChannelCategory)
        val cardContainer: View = itemView.findViewById(R.id.cardContainer)

        init {
            itemView.isFocusable = true
            itemView.isFocusableInTouchMode = true

            // TV Remote / D-pad focus gösterimi
            itemView.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    focusedPosition = adapterPosition
                    cardContainer.scaleX = 1.08f
                    cardContainer.scaleY = 1.08f
                    cardContainer.elevation = 16f
                    channelName.setTextColor(itemView.context.getColor(R.color.focused_text))
                } else {
                    cardContainer.scaleX = 1.0f
                    cardContainer.scaleY = 1.0f
                    cardContainer.elevation = 4f
                    channelName.setTextColor(itemView.context.getColor(R.color.normal_text))
                }
            }

            itemView.setOnClickListener {
                onChannelClick(channels[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]

        holder.channelName.text = channel.name
        holder.channelCategory.text = channel.category.displayName

        if (channel.logoUrl.isNotEmpty()) {
            Glide.with(holder.itemView.context)
                .load(channel.logoUrl)
                .placeholder(R.drawable.ic_tv_placeholder)
                .error(R.drawable.ic_tv_placeholder)
                .into(holder.channelLogo)
        } else {
            holder.channelLogo.setImageResource(R.drawable.ic_tv_placeholder)
        }

        // İlk öğe için odak isteği
        if (position == 0) {
            holder.itemView.requestFocus()
        }
    }

    override fun getItemCount() = channels.size
}
