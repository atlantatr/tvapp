package com.turktvbox.live.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.turktvbox.live.model.Channel
import com.turktvbox.live.repository.ChannelRepository
import kotlinx.coroutines.launch

sealed class ChannelState {
    object Loading : ChannelState()
    data class Ready(val channels: List<Channel>, val total: Int) : ChannelState()
    data class Error(val message: String, val fallback: List<Channel>) : ChannelState()
}

class ChannelViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = ChannelRepository(app)

    private val _state = MutableLiveData<ChannelState>(ChannelState.Loading)
    val state: LiveData<ChannelState> = _state

    private var selectedCategory = "Tümü"

    init { loadChannels() }

    fun loadChannels() {
        _state.value = ChannelState.Loading
        viewModelScope.launch {
            try {
                val all = repository.load()
                _state.postValue(ChannelState.Ready(
                    channels = repository.getByCategory(selectedCategory),
                    total    = all.size
                ))
            } catch (e: Exception) {
                _state.postValue(ChannelState.Error(
                    message  = e.message ?: "Bilinmeyen hata",
                    fallback = repository.channels
                ))
            }
        }
    }

    fun selectCategory(category: String) {
        selectedCategory = category
        _state.value = ChannelState.Ready(
            channels = repository.getByCategory(category),
            total    = repository.channels.size
        )
    }

    fun refresh() {
        repository.clearCache()
        loadChannels()
    }

    fun allCategories(): List<String> {
        val cats = repository.channels.map { it.category }.distinct().sorted()
        return listOf("Tümü") + cats
    }

    /** PlayerActivity için tam liste */
    fun allChannels(): List<Channel> = repository.channels
}
