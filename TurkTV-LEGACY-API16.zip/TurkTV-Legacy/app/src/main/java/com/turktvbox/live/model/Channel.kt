package com.turktvbox.live.model

import java.io.Serializable

data class Channel(
    val id: Int,
    val name: String,
    val streamUrl: String,
    val category: String,
    val logoUrl: String = "",
    val source: ChannelSource = ChannelSource.REMOTE
) : Serializable

enum class ChannelSource { BUILTIN, REMOTE }

object Categories {
    const val ALL          = "Tümü"
    const val ULUSAL       = "Ulusal"
    const val HABER        = "Haber"
    const val SPOR         = "Spor"
    const val BELGESEL     = "Belgesel"
    const val COCUK        = "Çocuk"
    const val MUZIK        = "Müzik"
    const val DINI         = "Dini"
    const val YEREL        = "Yerel"
    const val ULUSLARARASI = "Uluslararası"
    const val DIGER        = "Diğer"

    val all = listOf(ALL, ULUSAL, HABER, SPOR, BELGESEL, COCUK, MUZIK, DINI, YEREL, ULUSLARARASI, DIGER)

    fun normalize(raw: String): String {
        val lower = raw.lowercase().trim()
        return when {
            lower.contains("ulusal") || lower.contains("genel") || lower.contains("eğlence") -> ULUSAL
            lower.contains("haber") || lower.contains("news")                               -> HABER
            lower.contains("spor") || lower.contains("sport")                              -> SPOR
            lower.contains("belgesel") || lower.contains("kültür") || lower.contains("kultur") -> BELGESEL
            lower.contains("çocuk") || lower.contains("cocuk") || lower.contains("kids")   -> COCUK
            lower.contains("müzik") || lower.contains("muzik") || lower.contains("music")  -> MUZIK
            lower.contains("dini") || lower.contains("ilahi") || lower.contains("diyanet") -> DINI
            lower.contains("yerel") || lower.contains("local") || lower.contains("bölge")  -> YEREL
            lower.contains("uluslararası") || lower.contains("international")               -> ULUSLARARASI
            else                                                                            -> DIGER
        }
    }
}

object BuiltinChannels {
    val list = listOf(
        Channel(1,  "TRT 1",          "https://tv-trt1.medya.trt.com.tr/master.m3u8",        "Ulusal",       source = ChannelSource.BUILTIN),
        Channel(2,  "TRT 2",          "https://tv-trt2.medya.trt.com.tr/master.m3u8",        "Belgesel",     source = ChannelSource.BUILTIN),
        Channel(3,  "TRT Haber",      "https://tv-trthaber.medya.trt.com.tr/master.m3u8",    "Haber",        source = ChannelSource.BUILTIN),
        Channel(4,  "TRT Spor",       "https://tv-trtspor1.medya.trt.com.tr/master.m3u8",    "Spor",         source = ChannelSource.BUILTIN),
        Channel(5,  "TRT Spor Yıldız","https://tv-trtspor2.medya.trt.com.tr/master.m3u8",    "Spor",         source = ChannelSource.BUILTIN),
        Channel(6,  "TRT Müzik",      "https://tv-trtmuzik.medya.trt.com.tr/master.m3u8",    "Müzik",        source = ChannelSource.BUILTIN),
        Channel(7,  "TRT Belgesel",   "https://tv-trtbelgesel.medya.trt.com.tr/master.m3u8", "Belgesel",     source = ChannelSource.BUILTIN),
        Channel(8,  "TRT Çocuk",      "https://tv-trtcocuk.medya.trt.com.tr/master.m3u8",    "Çocuk",        source = ChannelSource.BUILTIN),
        Channel(9,  "TRT Kurdî",      "https://tv-trtkurdi.medya.trt.com.tr/master.m3u8",    "Ulusal",       source = ChannelSource.BUILTIN),
        Channel(10, "TRT Avaz",       "https://tv-trtavaz.medya.trt.com.tr/master.m3u8",     "Uluslararası", source = ChannelSource.BUILTIN),
        Channel(11, "TRT World",      "https://tv-trtworld.medya.trt.com.tr/master.m3u8",    "Uluslararası", source = ChannelSource.BUILTIN),
        Channel(12, "TRT Arabi",      "https://tv-trtarabi.medya.trt.com.tr/master.m3u8",    "Uluslararası", source = ChannelSource.BUILTIN),
    )
}
