package com.turktvbox.live

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.turktvbox.live.model.Channel
import com.turktvbox.live.model.ChannelStore

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_CHANNEL = "extra_channel"
        private const val OSD_HIDE_DELAY = 4000L
    }

    private lateinit var playerView: StyledPlayerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvChannelName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var ivChannelLogo: ImageView
    private lateinit var osdContainer: View
    private lateinit var btnBack: ImageButton
    private lateinit var btnReload: ImageButton

    private var player: ExoPlayer? = null
    private var currentChannel: Channel? = null
    private val osdHandler = Handler(Looper.getMainLooper())
    private val hideOsdRunnable = Runnable { hideOsd() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        makeFullScreen()

        playerView    = findViewById(R.id.playerView)
        progressBar   = findViewById(R.id.progressBar)
        tvChannelName = findViewById(R.id.tvChannelName)
        tvStatus      = findViewById(R.id.tvStatus)
        ivChannelLogo = findViewById(R.id.ivChannelLogo)
        osdContainer  = findViewById(R.id.osdContainer)
        btnBack       = findViewById(R.id.btnBack)
        btnReload     = findViewById(R.id.btnReload)

        currentChannel = intent.getSerializableExtra(EXTRA_CHANNEL) as? Channel
        btnBack.setOnClickListener { finish() }
        btnReload.setOnClickListener { currentChannel?.let { reloadChannel(it) } }
        currentChannel?.let { setupChannelInfo(it); initPlayer(it) } ?: finish()
        showOsd()
    }

    @Suppress("DEPRECATION")
    private fun makeFullScreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
    }

    private fun setupChannelInfo(channel: Channel) {
        tvChannelName.text = channel.name
        if (channel.logoUrl.isNotEmpty()) {
            Glide.with(this).load(channel.logoUrl)
                .placeholder(R.drawable.ic_tv_placeholder)
                .into(ivChannelLogo)
        } else {
            ivChannelLogo.setImageResource(R.drawable.ic_tv_placeholder)
        }
    }

    private fun initPlayer(channel: Channel) {
        player?.release()
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("TurkTV-Legacy/1.0 (Android)")
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(10_000)
            .setAllowCrossProtocolRedirects(true)

        val hlsSource = HlsMediaSource.Factory(dataSourceFactory)
            .createMediaSource(MediaItem.fromUri(channel.streamUrl))

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            playerView.useController = false
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> { progressBar.visibility = View.VISIBLE; tvStatus.text = "Yükleniyor..." }
                        Player.STATE_READY     -> { progressBar.visibility = View.GONE;    tvStatus.text = "Canlı" }
                        else                   -> { progressBar.visibility = View.GONE;    tvStatus.text = "Bağlantı kesildi" }
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@PlayerActivity, "Kanal yüklenemedi.", Toast.LENGTH_LONG).show()
                    showOsd()
                }
            })
            exo.setMediaSource(hlsSource)
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    private fun reloadChannel(channel: Channel) { initPlayer(channel) }

    private fun showOsd() {
        osdContainer.visibility = View.VISIBLE
        osdHandler.removeCallbacks(hideOsdRunnable)
        osdHandler.postDelayed(hideOsdRunnable, OSD_HIDE_DELAY)
    }

    private fun hideOsd() {
        osdContainer.animate().alpha(0f).setDuration(300).withEndAction {
            osdContainer.visibility = View.GONE
            osdContainer.alpha = 1f
        }.start()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> { finish(); true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_INFO -> { showOsd(); true }
            KeyEvent.KEYCODE_MEDIA_STOP -> { finish(); true }
            KeyEvent.KEYCODE_DPAD_UP,   KeyEvent.KEYCODE_CHANNEL_UP   -> { switchChannel(+1); true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { switchChannel(-1); true }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun switchChannel(direction: Int) {
        val all  = ChannelStore.channels
        if (all.isEmpty()) return
        val idx  = all.indexOfFirst { it.id == currentChannel?.id }.takeIf { it >= 0 } ?: 0
        val next = all[(idx + direction + all.size) % all.size]
        currentChannel = next
        setupChannelInfo(next)
        initPlayer(next)
        showOsd()
    }

    override fun onPause()   { super.onPause();   player?.pause() }
    override fun onResume()  { super.onResume();  player?.play(); makeFullScreen() }
    override fun onDestroy() {
        super.onDestroy()
        osdHandler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
