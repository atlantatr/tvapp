# 📺 Türk TV Canlı — LEGACY (Android 4.0.3+)

**minSdk: 16 (Android 4.0.3 Ice Cream Sandwich)**

ExoPlayer 2.x tabanlı, eski TV Box'lar için optimize edilmiş versiyon.

## Desteklenen Android Sürümleri
- ✅ Android 4.0.3 (API 16) ve üzeri
- ✅ Android 4.1, 4.2, 4.3, 4.4
- ✅ Android 5.0 ve üzeri

## Modern versiyondan farkları
- ExoPlayer 2.x kullanır (Media3 yerine)
- MultiDex etkin (API 16-20 arası için)
- `StyledPlayerView` widget'ı
- `android:name="androidx.multidex.MultiDexApplication"` Manifest'te tanımlı

## Derleme
```
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`
