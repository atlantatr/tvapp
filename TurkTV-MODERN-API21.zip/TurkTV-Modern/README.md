# 📺 Türk TV Canlı — MODERN (Android 5.0+)

**minSdk: 21 (Android 5.0 Lollipop)**

Media3 / ExoPlayer tabanlı, modern TV Box'lar için optimize edilmiş versiyon.

## Desteklenen Android Sürümleri
- ✅ Android 5.0 (API 21) ve üzeri
- ✅ Android 6, 7, 8, 9, 10, 11, 12, 13, 14

## Legacy versiyondan farkları
- AndroidX Media3 kullanır (en güncel)
- MultiDex gereksiz
- `PlayerView` widget'ı (Media3)
- Daha iyi codec desteği ve performans

## Derleme
```
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`
