# ExoPlayer 2.x
-keep class com.google.android.exoplayer2.** { *; }
-dontwarn com.google.android.exoplayer2.**

# Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { *; }

# MultiDex
-keep class androidx.multidex.** { *; }

# Channel model
-keep class com.turktvbox.live.model.** { *; }
