package com.turktvbox.live.repository

import com.turktvbox.live.model.Categories
import com.turktvbox.live.model.Channel
import com.turktvbox.live.model.ChannelSource

/**
 * Standart M3U / M3U8 playlist formatını parse eder.
 *
 * Desteklenen #EXTINF özellikleri:
 *   tvg-name, tvg-logo, tvg-id, group-title
 *
 * Örnek giriş:
 *   #EXTM3U
 *   #EXTINF:-1 tvg-name="TRT 1" tvg-logo="https://..." group-title="Ulusal",TRT 1
 *   https://tv-trt1.medya.trt.com.tr/master.m3u8
 */
object M3uParser {

    private val EXTINF_REGEX = Regex("""#EXTINF[^,]*,(.*)""")
    private val TVG_NAME_REGEX  = Regex("""tvg-name="([^"]*)"""")
    private val TVG_LOGO_REGEX  = Regex("""tvg-logo="([^"]*)"""")
    private val GROUP_REGEX     = Regex("""group-title="([^"]*)"""")

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()
        var idx = 0
        var idCounter = 10_000  // Yerleşik kanallarla çakışmaması için yüksek başla

        while (idx < lines.size) {
            val line = lines[idx].trim()

            if (line.startsWith("#EXTINF")) {
                val extinfLine = line

                // Sonraki URL satırını bul (boş satırları atla)
                var urlLine = ""
                var nextIdx = idx + 1
                while (nextIdx < lines.size) {
                    val candidate = lines[nextIdx].trim()
                    if (candidate.isNotEmpty() && !candidate.startsWith("#")) {
                        urlLine = candidate
                        break
                    }
                    nextIdx++
                }

                if (urlLine.isNotEmpty() && isValidUrl(urlLine)) {
                    // Kanal adı: önce tvg-name, yoksa satır sonu (virgül sonrası)
                    val tvgName  = TVG_NAME_REGEX.find(extinfLine)?.groupValues?.get(1)?.trim()
                    val commaName = EXTINF_REGEX.find(extinfLine)?.groupValues?.get(1)?.trim()
                    val name     = tvgName?.takeIf { it.isNotEmpty() }
                                   ?: commaName?.takeIf { it.isNotEmpty() }
                                   ?: "Bilinmeyen Kanal"

                    val logoUrl  = TVG_LOGO_REGEX.find(extinfLine)?.groupValues?.get(1)?.trim() ?: ""
                    val groupRaw = GROUP_REGEX.find(extinfLine)?.groupValues?.get(1)?.trim() ?: ""
                    val category = Categories.normalize(groupRaw)

                    channels.add(
                        Channel(
                            id       = idCounter++,
                            name     = name,
                            streamUrl= urlLine,
                            category = category,
                            logoUrl  = logoUrl,
                            source   = ChannelSource.REMOTE
                        )
                    )
                    idx = nextIdx + 1
                    continue
                }
            }
            idx++
        }

        return channels
    }

    private fun isValidUrl(url: String): Boolean =
        url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtmp://")
}
