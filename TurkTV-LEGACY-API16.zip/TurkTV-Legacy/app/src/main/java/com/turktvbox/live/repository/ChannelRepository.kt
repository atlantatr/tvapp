package com.turktvbox.live.repository

import android.content.Context
import android.util.Log
import com.turktvbox.live.model.BuiltinChannels
import com.turktvbox.live.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Kanal listesini şu öncelik sırasıyla sağlar:
 *  1. Uzak M3U listesi (streams.uzunmuhalefet.com/lists/tr.m3u)
 *  2. Önbelleğe alınmış M3U (önceki başarılı indirme)
 *  3. Yerleşik TRT kanalları (internet yoksa yedek)
 *
 * Uzak liste indirildiğinde yerleşik kanallarla birleştirilir;
 * aynı URL'ye sahip kanallar tekrar eklenmez.
 */
class ChannelRepository(private val context: Context) {

    companion object {
        private const val TAG          = "ChannelRepository"
        private const val REMOTE_URL   = "https://streams.uzunmuhalefet.com/lists/tr.m3u"
        private const val CACHE_FILE   = "channels_cache.m3u"
        private const val CACHE_MAX_AGE_MS = 6 * 60 * 60 * 1000L  // 6 saat
        private const val CONNECT_TIMEOUT = 15_000
        private const val READ_TIMEOUT    = 30_000
    }

    private var _channels: List<Channel> = emptyList()

    /** Mevcut kanal listesi (boş olabilir, load() çağrısından önce) */
    val channels: List<Channel> get() = _channels

    // ─── ANA YÜKLEME ─────────────────────────────────────────────────────────

    /**
     * Kanalları yükler; önce önbellekten, arka planda uzaktan günceller.
     * @return yüklenen kanal listesi
     */
    suspend fun load(): List<Channel> = withContext(Dispatchers.IO) {
        // 1) Önbellekte güncel veri varsa hemen dön
        val cached = loadFromCache()
        if (cached.isNotEmpty()) {
            _channels = mergeWithBuiltin(cached)
            Log.d(TAG, "Önbellekten ${_channels.size} kanal yüklendi")
        } else {
            // Önbellek yok ya da eski → yerleşikleri göster, arka planda indir
            _channels = BuiltinChannels.list
        }

        // 2) Uzak listeyi her zaman arka planda tazele
        try {
            val remote = fetchRemote()
            if (remote.isNotEmpty()) {
                saveToCache(remote)
                _channels = mergeWithBuiltin(remote)
                Log.d(TAG, "Uzaktan ${_channels.size} kanal yüklendi")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Uzak liste alınamadı: ${e.message}")
            // Önbellek de boşsa yerleşikleri kullan
            if (_channels.isEmpty()) _channels = BuiltinChannels.list
        }

        _channels
    }

    // ─── UZAK İNDİRME ────────────────────────────────────────────────────────

    private fun fetchRemote(): List<Channel> {
        val conn = (URL(REMOTE_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout   = CONNECT_TIMEOUT
            readTimeout      = READ_TIMEOUT
            requestMethod    = "GET"
            setRequestProperty("User-Agent", "TurkTV-Android/1.0")
            setRequestProperty("Accept", "*/*")
        }
        return try {
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val content = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
                M3uParser.parse(content)
            } else {
                Log.w(TAG, "HTTP ${conn.responseCode}")
                emptyList()
            }
        } finally {
            conn.disconnect()
        }
    }

    // ─── ÖNBELLEK ─────────────────────────────────────────────────────────────

    private fun cacheFile(): File = File(context.cacheDir, CACHE_FILE)

    private fun loadFromCache(): List<Channel> {
        val file = cacheFile()
        if (!file.exists()) return emptyList()
        val age = System.currentTimeMillis() - file.lastModified()
        if (age > CACHE_MAX_AGE_MS) return emptyList()          // 6 saatte bir yenile
        return try {
            M3uParser.parse(file.readText(Charsets.UTF_8))
        } catch (e: Exception) {
            Log.w(TAG, "Önbellek okunamadı: ${e.message}")
            emptyList()
        }
    }

    private fun saveToCache(channels: List<Channel>) {
        try {
            // Kanalları ham M3U formatında kaydet
            val sb = StringBuilder("#EXTM3U\n")
            channels.forEach { ch ->
                sb.append("""#EXTINF:-1 tvg-name="${ch.name}" tvg-logo="${ch.logoUrl}" group-title="${ch.category}",${ch.name}""")
                sb.append("\n${ch.streamUrl}\n")
            }
            cacheFile().writeText(sb.toString(), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w(TAG, "Önbelleğe yazılamadı: ${e.message}")
        }
    }

    // ─── BİRLEŞTİRME ─────────────────────────────────────────────────────────

    /**
     * Yerleşik TRT kanallarını başa ekler; uzak listede zaten varsa atlar.
     */
    private fun mergeWithBuiltin(remote: List<Channel>): List<Channel> {
        val remoteUrls = remote.map { it.streamUrl.trim().lowercase() }.toSet()
        val unique = BuiltinChannels.list.filter {
            it.streamUrl.trim().lowercase() !in remoteUrls
        }
        return unique + remote
    }

    // ─── YARDIMCI ─────────────────────────────────────────────────────────────

    fun getByCategory(category: String): List<Channel> =
        if (category == "Tümü") _channels
        else _channels.filter { it.category == category }

    fun clearCache() = cacheFile().delete()
}
