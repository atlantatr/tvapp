package com.turktvbox.live

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.turktvbox.live.adapter.ChannelAdapter
import com.turktvbox.live.model.Channel
import com.turktvbox.live.model.ChannelStore
import com.turktvbox.live.viewmodel.ChannelState
import com.turktvbox.live.viewmodel.ChannelViewModel

class MainActivity : AppCompatActivity() {

    private val viewModel: ChannelViewModel by viewModels()

    private lateinit var rvChannels: RecyclerView
    private lateinit var tabRow: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvChannelCount: TextView
    private lateinit var loadingView: View
    private lateinit var btnRefresh: View

    private var tabViews = listOf<TextView>()
    private var selectedCat = "Tümü"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvChannels     = findViewById(R.id.rvChannels)
        tabRow         = findViewById(R.id.tabRow)
        tvStatus       = findViewById(R.id.tvStatus)
        tvChannelCount = findViewById(R.id.tvChannelCount)
        loadingView    = findViewById(R.id.loadingView)
        btnRefresh     = findViewById(R.id.btnRefresh)

        btnRefresh.setOnClickListener { viewModel.refresh() }

        viewModel.state.observe(this) { state ->
            when (state) {
                is ChannelState.Loading -> {
                    loadingView.visibility = View.VISIBLE
                    rvChannels.visibility  = View.GONE
                    tvStatus.text          = "Kanal listesi güncelleniyor..."
                }
                is ChannelState.Ready -> {
                    loadingView.visibility = View.GONE
                    rvChannels.visibility  = View.VISIBLE
                    tvChannelCount.text    = "${state.total} kanal"
                    tvStatus.text          = "✓ ${state.total} kanal hazır"
                    ChannelStore.channels  = viewModel.allChannels()
                    buildTabs()
                    showChannels(state.channels)
                }
                is ChannelState.Error -> {
                    loadingView.visibility = View.GONE
                    rvChannels.visibility  = View.VISIBLE
                    tvStatus.text          = "⚠ Hata — yedek liste gösteriliyor"
                    Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                    if (state.fallback.isNotEmpty()) {
                        ChannelStore.channels = state.fallback
                        showChannels(state.fallback)
                    }
                }
            }
        }
    }

    private fun buildTabs() {
        val categories = viewModel.allCategories()
        tabRow.removeAllViews()
        tabViews = categories.mapIndexed { i, cat ->
            val tab = layoutInflater.inflate(R.layout.item_tab, tabRow, false) as TextView
            tab.text = cat
            tab.isFocusable = true
            tab.isFocusableInTouchMode = true
            tab.setOnClickListener {
                selectedCat = cat
                highlightTab(i)
                viewModel.selectCategory(cat)
            }
            tab.setOnFocusChangeListener { _, hasFocus ->
                tab.scaleX = if (hasFocus) 1.05f else 1.0f
                tab.scaleY = if (hasFocus) 1.05f else 1.0f
            }
            tabRow.addView(tab)
            tab
        }
        highlightTab(0)
    }

    private fun highlightTab(idx: Int) {
        tabViews.forEachIndexed { i, tab ->
            if (i == idx) {
                tab.setBackgroundResource(R.drawable.tab_selected_bg)
                tab.setTextColor(getColor(R.color.tab_selected_text))
            } else {
                tab.setBackgroundResource(R.drawable.tab_unselected_bg)
                tab.setTextColor(getColor(R.color.tab_unselected_text))
            }
        }
    }

    private fun showChannels(channels: List<Channel>) {
        val spanCount = if (resources.configuration.screenWidthDp >= 960) 6 else 3
        rvChannels.layoutManager = GridLayoutManager(this, spanCount)
        rvChannels.adapter = ChannelAdapter(channels) { ch -> openPlayer(ch) }
        rvChannels.post { rvChannels.getChildAt(0)?.requestFocus() }
    }

    private fun openPlayer(channel: Channel) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL, channel)
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && selectedCat != "Tümü") {
            selectedCat = "Tümü"
            highlightTab(0)
            viewModel.selectCategory("Tümü")
            tabViews.firstOrNull()?.requestFocus()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
