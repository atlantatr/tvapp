package com.turktvbox.live.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.turktvbox.live.R
import com.turktvbox.live.model.Channel

class ChannelAdapter(
    private val channels: List<Channel>,
    private val onChannelClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val channelName: TextView     = itemView.findViewById(R.id.tvChannelName)
        val channelLogo: ImageView    = itemView.findViewById(R.id.ivChannelLogo)
        val channelCategory: TextView = itemView.findViewById(R.id.tvChannelCategory)
        val cardContainer: View       = itemView.findViewById(R.id.cardContainer)

        init {
            itemView.isFocusable = true
            itemView.isFocusableInTouchMode = true
            itemView.setOnFocusChangeListener { _, hasFocus ->
                cardContainer.scaleX    = if (hasFocus) 1.08f else 1.0f
                cardContainer.scaleY    = if (hasFocus) 1.08f else 1.0f
                cardContainer.elevation = if (hasFocus) 16f else 4f
                channelName.setTextColor(
                    itemView.context.getColor(if (hasFocus) R.color.focused_text else R.color.normal_text)
                )
            }
            itemView.setOnClickListener { onChannelClick(channels[adapterPosition]) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        holder.channelName.text     = channel.name
        holder.channelCategory.text = channel.category   // artık direkt String

        if (channel.logoUrl.isNotEmpty()) {
            Glide.with(holder.itemView.context)
                .load(channel.logoUrl)
                .placeholder(R.drawable.ic_tv_placeholder)
                .error(R.drawable.ic_tv_placeholder)
                .into(holder.channelLogo)
        } else {
            holder.channelLogo.setImageResource(R.drawable.ic_tv_placeholder)
        }
        if (position == 0) holder.itemView.requestFocus()
    }

    override fun getItemCount() = channels.size
}
