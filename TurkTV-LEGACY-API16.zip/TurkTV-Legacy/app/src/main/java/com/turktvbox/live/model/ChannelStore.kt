package com.turktvbox.live.model

/**
 * MainActivity'den yüklenen kanal listesini
 * PlayerActivity'de de kullanabilmek için tutar.
 */
object ChannelStore {
    var channels: List<Channel> = BuiltinChannels.list
}
